#include "bstdb.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
int g_next_id = 0;
int g_num_comps = 0;
int g_num_searches = 0;

int insertionOrder[100];

const int maxQueries = 131071;


typedef struct Node Node;
struct Node{
	int ID;
    int wordCount;
	char title[100];
    Node * prev;
    Node * branch1;
    Node * branch2;
};

void sortForInsertion(int array[], int size);

void partition(int array[], int lowerIndex, int upperIndex);

void insertTree(Node ** headPointer, int value, char title[100], int wordCount);

Node * nextVal(Node * originalPtr);

Node * getLowestVal(Node * headPointer);

Node * root;

void populateArray(int *array, int lowerIndex, int upperIndex, int index);

void tree_delete();

void deleteNode(Node ** ptr);

Node * getRootToDelete(Node * ptr);

int * arrayPtr = NULL;

int bstdb_init ( void ) {
    int size = maxQueries;
    int array[maxQueries];
    arrayPtr = array;
    populateArray(array, 0, size - 1, 1);
	root = NULL;
	g_next_id = 0;
	g_num_searches = 0;
	g_num_comps = 0;
	return 1;
}

int bstdb_add ( char *name, int word_count ) {
    
    g_next_id++;
	insertTree(&root, arrayPtr[g_next_id], name, word_count);
	return arrayPtr[g_next_id];
}

int insertCounter = 0;
int insertCounterSum = 0;
//A function to insert a value into a tree
void insertTree(Node ** headPointer, int value, char title[100], int wordCount){
    insertCounter++;
    int counter = 0;
    if(*headPointer == NULL){
        *headPointer = (Node *)malloc(sizeof(Node));
        (*(*headPointer)).ID = value;
		strcpy((*(*headPointer)).title, title);
		(*(*headPointer)).wordCount = wordCount;
        (*(*headPointer)).branch1 = NULL;
        (*(*headPointer)).branch2 = NULL;
        (*(*headPointer)).prev = NULL;
        return;
    }
    Node * temp = (Node*)malloc(sizeof(Node));
    Node * destinationPtr = *headPointer;
    (*temp).ID = value;
	(*temp).wordCount = wordCount;
	strcpy((*temp).title, title);
    (*temp).branch1 = NULL;
    (*temp).branch2 = NULL;
    (*temp).prev = NULL;
    int exitCondition = 0;
    while(exitCondition == 0){
        counter++;
        if(value <= (*destinationPtr).ID){
            if ((*destinationPtr).branch1 != NULL){
                destinationPtr = (*destinationPtr).branch1;
            }
            else{
                (*temp).prev = destinationPtr;
                (*destinationPtr).branch1 = temp;
                exitCondition = 1;
            }
            } else {
            if ((*destinationPtr).branch2 != NULL){
                destinationPtr = (*destinationPtr).branch2;
            }
            else{
                (*temp).prev = destinationPtr;
                (*destinationPtr).branch2 = temp;
                
                exitCondition = 1;
            }
        }
    }
    insertCounterSum = insertCounterSum + counter;
    return;
}

int wordCountSearchSum = 0;
int wordCountSearchCounter = 0;
int bstdb_get_word_count ( int doc_id ) {
    wordCountSearchCounter++;
    Node * ptr = root;
    while (ptr != NULL){
        wordCountSearchSum++;
        if(doc_id < (*ptr).ID){
            ptr = (*ptr).branch1;
        } else if (doc_id > (*ptr).ID){
            ptr = (*ptr).branch2;
        } else {
            break;
        }
    }
    if (ptr != NULL && (*ptr).ID == doc_id){
        return ((*ptr).wordCount);
    }
	return -1;
}

int titleSearchSum = 0;
int titleSearchCounter = 0;
char* bstdb_get_name ( int doc_id ) {
    titleSearchCounter++;
    Node * ptr = root;
    while (ptr != NULL){
        titleSearchSum++;
        if(doc_id < (*ptr).ID){
            ptr = (*ptr).branch1;
        } else if (doc_id > (*ptr).ID){
            ptr = (*ptr).branch2;
        } else {
            break;
        }
    }
    if (ptr != NULL && (*ptr).ID == doc_id){
        return ((*ptr).title);
    }
	return 0;
}

void
bstdb_stat ( void ) {
    int averageTitleSearchCounter = titleSearchSum/titleSearchCounter;
    int averageWordSearchCounter = wordCountSearchSum/wordCountSearchCounter;
    int averageInsertCounter = insertCounterSum/insertCounter;
    printf("Average depth for insert %i\n", averageInsertCounter);
    printf("Average depth for search for word %i\n", averageWordSearchCounter);
    printf("Average depth for search for title %i\n", averageTitleSearchCounter);
    printf("Tree is balanced\n");
}

void
bstdb_quit ( void ) {
    tree_delete();
}

//A function which will delete every node from a tree and free up the memory
void tree_delete(){
    for(;;){
        Node * ptr = root;
        if(((*root).branch1 == NULL) && (*root).branch2 == NULL){
            free(root);
            return;
        } else {
            ptr = getRootToDelete(ptr);
            deleteNode(&ptr);
        }
    }
}

Node * getRootToDelete(Node * ptr){
    if((*ptr).branch1 != NULL){
        ptr = (*ptr).branch1; 
        ptr = getRootToDelete(ptr);
    } else if ((*ptr).branch2 != NULL){
        ptr = (*ptr).branch2;
        ptr = getRootToDelete(ptr);
    }
    return ptr;
}

void deleteNode(Node ** ptr){
    if((*(**ptr).prev).branch1 == *ptr){
        (*(**ptr).prev).branch1 = NULL;
    } else if((*(**ptr).prev).branch2 == *ptr){
        (*(**ptr).prev).branch2 = NULL;
    }
    free(*ptr);
    *ptr = NULL;
}

void printTree(Node * headPointer){
    Node * ptr = NULL;
    if (headPointer == NULL){
        return;
    } else{
        ptr = getLowestVal(headPointer);
        printf("Title is %s, ID is %i\n", (*ptr).title, (*ptr).ID);
        while(ptr != NULL){
            ptr = nextVal(ptr);
            if(ptr != NULL){
                printf("Title is %s, ID is %i\n", (*ptr).title, (*ptr).ID);
            }
        }
    }
}

//A function to find the nextvalue in a tree
Node * nextVal(Node * originalPtr){
    int currentval = (*originalPtr).ID;
    if((*originalPtr).branch2 != NULL){
        originalPtr = (*originalPtr).branch2;
        originalPtr = getLowestVal(originalPtr);
        return originalPtr;
    } else{
        while((*(*originalPtr).prev).ID < currentval){
            originalPtr = (*originalPtr).prev;  
            if((*originalPtr).prev == NULL){
                return NULL;
            }
        }
        originalPtr = (*originalPtr).prev;
        return originalPtr;
    }
    return NULL;
}

//A function get the lowest value in a binary search tree
Node * getLowestVal(Node * headPointer){
    while ((*headPointer).branch1 != NULL){
        headPointer = (*headPointer).branch1;
    }
    return headPointer;
}

void populateArray(int *array, int lowerIndex, int upperIndex, int index){
    if((upperIndex - lowerIndex) >= 0){
        int median = floor((upperIndex - lowerIndex)/2 + lowerIndex);
        //printf("%i  %i  %i\n", lowerIndex, median, upperIndex);
        array[index - 1] = median;
        populateArray(array, lowerIndex, median - 1, 2 * index);
        populateArray(array, median + 1, upperIndex, (2 * index) + 1);
    }
}